- Ce dossier contient les données utilisées pour construire le modèle d'apprentissage,ainsi que les données utilisées pour l'évaluation du modèle construit.

# Données d'apprentissage 

Les données d'apprentissage sont dans le dossier "Training model", ils sont à la fois sous format arff qui est utilisé par Weka et au format csv pour une meilleure visualisation des données. Chaque pair de mentions est décrite par 25 attributs.

1) 'mention 1' : cet attribut indique le texte de la première mention, il est entre guillemets quand le texte contient une virgule pour éviter toute ambiguité lors de la lécture au format csv.

2) 'annotation 1' : cet attribut donne l'annotation en fonction syntaxique de la première mention

3) 'N° phrase 1' : cet attribut indique le numéro de phrase de la première mention

4) 'Singulier 1' : cet attribut indique le nombre de la première mention, il est marqué "VRAI" quand la mention est au singulier, sinon "FAUX"

5)'genre m1' : cet attribut le genre de de la première mention, "MASCULIN" ou "FEMININ"

6)'pronom m1' : cet attribut indique si de la première mention est un pronom, "VRAI"/"FAUX"

7)'SN demonstratif m1' : cet attribut indique si de la première mention est un SN démonstratif, "VRAI"/"FAUX"

8)'SN defini m1' : cet attribut indique si de la première mention est un SN défini, "VRAI"/"FAUX"

9)'nom propre m1' : cet attribut indique si de la première mention est un nom propre, "VRAI"/"FAUX"

10) 'mention 2' : cet attribut cet attribut indique le texte de la deuxième mention

11) 'annotation 2' : cet attribut donne l'annotation en fonction syntaxique de la deuxième mention

12) 'pronom m²' : cet attribut indique si de la deuxième mention est un pronom, "VRAI"/"FAUX"

13) 'SN demonstratif m²' : cet attribut indique si de la deuxième mention est un SN démonstratif, "VRAI"/"FAUX"

14) 'SN defini m²' : cet attribut indique si de la deuxième mention est un SN défini, "VRAI"/"FAUX"

15) 'genre m2' : cet attribut le genre de de la deuxième mention, "MASCULIN" ou "FEMININ"

16) 'Singulier m²' : cet attribut indique le nombre de la deuxième mention, il est marqué "VRAI" quand la mention est au singulier, sinon "FAUX"

17) 'nom propre m²' : cet attribut indique si de la deuxième mention est un nom propre, "VRAI"/"FAUX"

18)'N° phrase 2' : cet attribut indique le numéro de phrase de la deuxième mention

19)'meme genre' : cet attribut indique si la première et la deuxième mention ont le meme genre, "VRAI"/"FAUX" 

20) 'meme nombre' : cet attribut indique si la première et la deuxième mention ont le meme nombre, "VRAI"/"FAUX"

21) distance : cet attribut indique la distance entre les deux mentions, un nombre entier

22) 'meme taille' : cet attribut indique si la première et la deuxième mention ont la meme taille, "VRAI"/"FAUX"

23) 'sont noms propres' : cet attribut indique si les deux mentions sont des noms propres, "VRAI"/"FAUX"

24) alias : cet attribut si une mention est un alias de l'autre mention

25)resultat : cet attribut si les deux mention sont coréférentes, "oui"/"non"

# Données d'évaluation

Les données utilisées pour l'évaluation du modèle sont le dossier "Evaluation model", ce dernier contient à la fois les données utilisées pour créer un modèle d'évaluation qui ont les meme attributs décrits ci-dessus, ainsi que les sorties de Cofr pour comparer avec les sorties de notre modèle. Les sorties Cofr sont au format conll et jsonlines.

